package com.vtalent.sreenivasa;

import java.util.Arrays;

public class Exception1 extends Exception
{
	public Exception1(String str)
	{
		super(str);
	}
}
