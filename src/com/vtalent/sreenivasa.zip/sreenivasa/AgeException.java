package com.vtalent.sreenivasa;

public class AgeException extends Exception
{
	public String toString()
	{
		return "Your eligible>22";
	}

}
