package com.vtalent.sreenivasa;

public class Xyz
{
	int x,y;
	String name;
 public static void main(String[] args) {
		// TODO Auto-generated method stub
		Xyz sree=new Xyz();
System.out.println("the value of string is:"+sree.name+"the value of x is:"+sree.x+"the value of y is:"+sree.y);

	}
}
