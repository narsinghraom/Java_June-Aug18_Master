package com.vtalent.sreenivasa;

public class Sreenivasa 
{
	
	String str;
	char ch=str.charAt(0);
	void disp() 
	{
		System.out.println(ch);
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		/*String str;
		char ch=str.charAt(0);*/
		Sreenivasa s=new Sreenivasa();
		s.disp();
System.out.println("hiii");
	}

}
